# 5. Indexing
nume = 'Madalin'
# value M a d a l i n
# index 0 1 2 3 4 5 6

# newline  \n
print('My\ndog')
# tab      \t
print('my\tdog')
# backlash \\
print('my\\dog')

# range(from, to, step), 'to' means up to, but not including it
# range (2, 15, 3)
print(range(2, 15, 3))
for a in range(5):
    print(a)
for b in range(3, 5):
    print(b)
for c in range(1, 10, 2):
    print(c)
for d in range(15, 10, -1):
    print(d)