# 3. Input
name = input('Enter your name:')
print('Hello', name)
age = eval((input('Age:')))
print('Age:', age)
lungimea = eval(input('Lungimea dreptunghiului:'))
latimea = eval('Latimea dreptunghiului:')
aria = lungimea * latimea
print('Aria dreptunghiului este:', aria)